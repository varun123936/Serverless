const AWS = require('aws-sdk')

//const KEY_ID = "AKIAZVXTSXFRRU2ZOS7I"
//const SECRET_KEY = "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"

const s3 = new AWS.S3({
    //accessKeyId:KEY_ID,
    //secretAccessKey:SECRET_KEY,
});

const upload = async ()=>{
       const params={
        //ACL:"public-read",
        Body : 'hello world',
        ContentType:"text/html",
        Bucket:"wornoffkeys321",
        Key:'file-from-lambda.txt'
    }

    return await new Promise((resolve,reject)=>{
        s3.putObject(params,(err,results)=>{
            if(err){
                reject(err)
            }
            else{
                resolve(results)
            }
        })
    })
}

const main = async (event)=>{
    console.log("Event: ",event)
    return upload()
}
exports.handler = main