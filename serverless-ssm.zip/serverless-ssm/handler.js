'use strict';

const AWS=require('aws-sdk');
const ssm=new AWS.SSM();
AWS.config.update({region:'ap-south-1'});

module.exports.hello = async (event) => {

  try{
    const result=await ssm.getParameter({
      Name: "external-api-url"
    }).promise();

  }catch(error){
    console.log(error)
    }
  
  return {
    statusCode: 200,
    body: JSON.stringify(result,
      null,
      2
    ),
  };

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};
