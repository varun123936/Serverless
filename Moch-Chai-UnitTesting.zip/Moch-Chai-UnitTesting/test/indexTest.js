const assert = require('chai').assert;
//const sayHello=require('../index').sayHello;
//const addNumbers=require('../index').addNumbers;
const app = require('../index');

describe('App',function(){
    it('sayHello should return hello',function(){
        let result=app.sayHello();
        assert.equal(result,'hello');
    });

    it('sayHello should return type string',function(){
        let result=app.sayHello();
        assert.typeOf(result,'string');
    });

    it('addNumbers',function(){
        let result=app.addNumbers(2,3);
        assert.equal(result,5);
    });

    it('addNumbers should be above 5',function(){
        let result=app.addNumbers(5,5);
        assert.isAbove(result,5);
    });

    it('subtractNumbers',function(){
        let result=app.subtractNumbers(5,3);
        assert.equal(result,2);
    });

    it('multiplyNumbers',function(){
        let result=app.multiplyNumbers(5,3);
        assert.equal(result,15);
    });

    it('divisionNumbers',function(){
        let result=app.divisionNumbers(4,2);
        assert.equal(result,2);
    });

})