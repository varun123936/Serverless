module.exports={
    sayHello: function(){
        return 'hello';
    },
    addNumbers: function(num1,num2){
        return num1+num2;
    },
    subtractNumbers: function(num1,num2){
        return num1-num2;
    },
    multiplyNumbers: function(num1,num2){
        return num1*num2;
    },
    divisionNumbers: function(num1,num2){
        return num1/num2;
    },

}